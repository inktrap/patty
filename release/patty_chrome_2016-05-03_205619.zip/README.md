# Bugs

 - :tada:


# ToDo

 - be proud & happy!!! first addon :) yay <3 :tada: :clap: :smile:
 - styling?
 - test with safari and opera?
 - maybe write profiles, like trump, sanders, cyber, cloud, … (load them from json?)
 - maybe hide the addon button so it's more pranky?

# Done

 - x the dom tree gets traversed multiple times, this makes the order of rules unimportant
 - x regexes should be compiled only once
 - x always handing over the settings via a parameter -- there has to be a better way … ask on SO (this is not really a bug) (thought about it for a minute and used a class instead of functions …

# Prerequisites

 - firefox build: ``jq``
 - firefox development: [extension auto installer](https://github.com/palant/autoinstaller)

