# Bugs

 - always handing over the settings via a parameter -- there has to be a better way … ask on SO (this is not really a bug)


# ToDo

 - styling
 - test with safari and mozilla
 - maybe write profiles, like trump, sanders, cyber, cloud, … (load them via json?)
 - be proud & happy!!! first addon :) yay <3 :tada: :clap: :smile:


# Done

 - x the dom tree gets traversed multiple times, this makes the order of rules unimportant
 - x regexes should be compiled only once

# Prerequisites

 - firefox build: ``jq``
 - firefox development: [extension auto installer](https://github.com/palant/autoinstaller)

